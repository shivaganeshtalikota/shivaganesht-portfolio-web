Shiva Ganesh Talikota: logo kit

Night #0c0b0a  Paper #faf9f7  Ink #14130f  Cream #f2f0ec
Vermilion #ff5c26 (on dark)  #c93800 (on light)

Leave at least a quarter of the mark's width clear around it.
Don't stretch it, recolour the S, or move the dot.

https://shivaganeshtalikota.vercel.app/brand
